import * as THREE from 'three';
const canvas = document.querySelector('.webgl');
const scene = new THREE.Scene();
const sizes = { width: window.innerWidth, height: window.innerHeight };
const camera = new THREE.PerspectiveCamera(75, sizes.width/sizes.height, 0.1, 100);
camera.position.set(0,1.2,3); scene.add(camera);
const renderer = new THREE.WebGLRenderer({canvas, antialias:true}); renderer.setSize(sizes.width,sizes.height); renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));

const loader = new THREE.TextureLoader();
const colorTex = loader.load('/textures/door/color.jpg');
const normalTex = loader.load('/textures/door/normal.jpg');
const aoTex = loader.load('/textures/door/ambientOcclusion.jpg');
const gradient = loader.load('/textures/gradients/3.jpg');

/* transforms */
colorTex.repeat.set(2,2); colorTex.wrapS = THREE.RepeatWrapping; colorTex.wrapT = THREE.RepeatWrapping;
colorTex.center.set(0.5,0.5); colorTex.rotation = Math.PI*0.25;

/* filtering for gradient */
gradient.minFilter = THREE.NearestFilter; gradient.magFilter = THREE.NearestFilter; gradient.generateMipmaps = false;

const material = new THREE.MeshStandardMaterial({ map: colorTex, normalMap: normalTex, aoMap: aoTex });
const geo = new THREE.BoxGeometry(1,1,1, 100,100,100);
geo.setAttribute('uv2', new THREE.BufferAttribute(geo.attributes.uv.array, 2));
const mesh = new THREE.Mesh(geo, material);
scene.add(mesh);

window.addEventListener('resize', () => {
  sizes.width = window.innerWidth; sizes.height = window.innerHeight;
  camera.aspect = sizes.width / sizes.height; camera.updateProjectionMatrix();
  renderer.setSize(sizes.width, sizes.height); renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
});

const tick = () => { mesh.rotation.y += 0.005; renderer.render(scene,camera); requestAnimationFrame(tick); };
tick();
