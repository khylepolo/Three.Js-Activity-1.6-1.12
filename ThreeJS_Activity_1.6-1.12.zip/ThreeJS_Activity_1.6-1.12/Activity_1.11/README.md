Content for Activity 1.11 and 1.12 was not available in the provided PDF (the file was truncated).
Placeholders are provided here. Replace this README with the actual instructions or supply the missing PDF pages,
and I will generate full implementations for 1.11 and 1.12.
