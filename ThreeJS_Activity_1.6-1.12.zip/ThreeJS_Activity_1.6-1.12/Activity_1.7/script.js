import * as THREE from 'three';
const canvas = document.querySelector('.webgl');
const scene = new THREE.Scene();
const sizes = { width: window.innerWidth, height: window.innerHeight };
const camera = new THREE.PerspectiveCamera(75, sizes.width/sizes.height, 0.1, 100);
camera.position.set(0,1.5,4); scene.add(camera);
const renderer = new THREE.WebGLRenderer({canvas, antialias:true});
renderer.setSize(sizes.width, sizes.height); renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));

/* Built-in geometries */
const box = new THREE.Mesh(new THREE.BoxGeometry(1,1,1), new THREE.MeshNormalMaterial());
box.position.x = -2; scene.add(box);
const sphere = new THREE.Mesh(new THREE.SphereGeometry(0.8, 32, 32), new THREE.MeshNormalMaterial());
sphere.position.x = 0; scene.add(sphere);
const torus = new THREE.Mesh(new THREE.TorusGeometry(0.6,0.25,16,48), new THREE.MeshNormalMaterial());
torus.position.x = 2; scene.add(torus);

/* BufferGeometry triangle */
const triGeom = new THREE.BufferGeometry();
const positions = new Float32Array([0,0,0, 0,1,0, 1,0,0]);
triGeom.setAttribute('position', new THREE.BufferAttribute(positions, 3));
const tri = new THREE.Mesh(triGeom, new THREE.MeshBasicMaterial({color:0x00ff00, side: THREE.DoubleSide}));
tri.position.set(0,-1.2,0); scene.add(tri);

/* many random triangles */
const count = 50;
const randGeom = new THREE.BufferGeometry();
const randPositions = new Float32Array(count * 3 * 3);
for (let i=0;i<count*3*3;i++) randPositions[i] = (Math.random()-0.5)*4;
randGeom.setAttribute('position', new THREE.BufferAttribute(randPositions, 3));
const randMesh = new THREE.Mesh(randGeom, new THREE.MeshBasicMaterial({color:0x8833ff}));
randMesh.position.set(0,-2.2,0); scene.add(randMesh);

/* resize */
window.addEventListener('resize', () => {
  sizes.width = window.innerWidth; sizes.height = window.innerHeight;
  camera.aspect = sizes.width / sizes.height; camera.updateProjectionMatrix();
  renderer.setSize(sizes.width, sizes.height);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
});

const tick = () => {
  const t = Date.now() * 0.001;
  box.rotation.y = 0.2 * t; sphere.rotation.y = 0.2 * t; torus.rotation.y = 0.2 * t;
  renderer.render(scene, camera); requestAnimationFrame(tick);
};
tick();
