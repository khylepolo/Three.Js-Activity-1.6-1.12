import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
const canvas = document.querySelector('.webgl');
const scene = new THREE.Scene();
const sizes = { width: window.innerWidth, height: window.innerHeight };
const camera = new THREE.PerspectiveCamera(60, sizes.width/sizes.height, 0.1, 100);
camera.position.set(0,1.2,3); scene.add(camera);
const renderer = new THREE.WebGLRenderer({canvas, antialias:true}); renderer.setSize(sizes.width,sizes.height); renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
const controls = new OrbitControls(camera, canvas); controls.enableDamping = true;

const textureLoader = new THREE.TextureLoader();
const doorColor = textureLoader.load('/textures/door/color.jpg');
const matBasic = new THREE.MeshBasicMaterial({ map: doorColor });
const matNormal = new THREE.MeshNormalMaterial();
const matMatcap = new THREE.MeshMatcapMaterial({ matcap: textureLoader.load('/textures/matcaps/1.png') });
const matStandard = new THREE.MeshStandardMaterial({ map: doorColor, metalness:0.2, roughness:0.8 });

const sphere = new THREE.Mesh(new THREE.SphereGeometry(0.6, 64,64), matStandard);
sphere.position.x = -1.5;
const plane = new THREE.Mesh(new THREE.PlaneGeometry(1,1), matStandard);
const torus = new THREE.Mesh(new THREE.TorusGeometry(0.5,0.2, 64, 128), matStandard);
torus.position.x = 1.5;
scene.add(sphere, plane, torus);

const ambient = new THREE.AmbientLight(0xffffff, 0.5); scene.add(ambient);
const point = new THREE.PointLight(0xffffff, 0.6); point.position.set(2,3,4); scene.add(point);

/* uv2 for aoMap if needed */
sphere.geometry.setAttribute('uv2', new THREE.BufferAttribute(sphere.geometry.attributes.uv.array, 2));
plane.geometry.setAttribute('uv2', new THREE.BufferAttribute(plane.geometry.attributes.uv.array, 2));
torus.geometry.setAttribute('uv2', new THREE.BufferAttribute(torus.geometry.attributes.uv.array, 2));

window.addEventListener('resize', () => {
  sizes.width = window.innerWidth; sizes.height = window.innerHeight;
  camera.aspect = sizes.width / sizes.height; camera.updateProjectionMatrix();
  renderer.setSize(sizes.width, sizes.height); renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
});

const tick = () => { const t = Date.now()*0.001; sphere.rotation.y = 0.1*t; plane.rotation.y = 0.1*t; torus.rotation.y = 0.1*t; controls.update(); renderer.render(scene,camera); requestAnimationFrame(tick); };
tick();
