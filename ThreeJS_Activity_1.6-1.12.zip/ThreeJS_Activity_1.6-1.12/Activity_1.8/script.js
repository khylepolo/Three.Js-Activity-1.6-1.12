import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import * as dat from 'lil-gui';
import gsap from 'gsap';
const canvas = document.querySelector('.webgl');
const scene = new THREE.Scene();
const sizes = { width: window.innerWidth, height: window.innerHeight };
const camera = new THREE.PerspectiveCamera(60, sizes.width/sizes.height, 0.1, 100);
camera.position.set(0,1.2,3); scene.add(camera);
const renderer = new THREE.WebGLRenderer({canvas, antialias:true});
renderer.setSize(sizes.width, sizes.height); renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
const controls = new OrbitControls(camera, canvas); controls.enableDamping = true;
const geom = new THREE.BoxGeometry(1,1,1);
const meshMat = new THREE.MeshStandardMaterial({color:0xff5555});
const mesh = new THREE.Mesh(geom, meshMat); scene.add(mesh);
const ambient = new THREE.AmbientLight(0xffffff, 0.5); scene.add(ambient);
const point = new THREE.PointLight(0xffffff, 0.5); point.position.set(2,3,4); scene.add(point);

/* GUI */
const gui = new dat.GUI();
const params = { color: 0xff5555, wireframe: false, spin: () => {
  gsap.to(mesh.rotation, {duration:1, y: mesh.rotation.y + Math.PI*2});
}};
gui.addColor(params, 'color').onChange(v => mesh.material.color.set(v));
gui.add(mesh.material, 'metalness', 0, 1, 0.01);
gui.add(mesh.material, 'roughness', 0, 1, 0.01);
gui.add(params, 'wireframe').onChange(v => mesh.material.wireframe = v);
gui.add(params, 'spin');

/* resize */
window.addEventListener('resize', () => {
  sizes.width = window.innerWidth; sizes.height = window.innerHeight;
  camera.aspect = sizes.width / sizes.height; camera.updateProjectionMatrix();
  renderer.setSize(sizes.width, sizes.height);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
});

const tick = () => { controls.update(); renderer.render(scene,camera); requestAnimationFrame(tick); };
tick();
